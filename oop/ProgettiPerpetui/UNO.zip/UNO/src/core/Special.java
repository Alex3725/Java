package core;

public enum Special {
    CAMBIO_GIRO,
    PIU_QUATTRO,
    PIU_DUE,
    BLOCCA,
    CAMBIO_COLORE,
}
