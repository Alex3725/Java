package core;

public enum Colori {
    ROSSO,
    VERDE,
    GIALLO,
    BLU
}
