public enum modalitaFunzionamento {
    ERROR,
    Eco,
    Performance,
    Standby,
    Manuale
}
