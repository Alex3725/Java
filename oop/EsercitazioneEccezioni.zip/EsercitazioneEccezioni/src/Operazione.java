public class Operazione {

    public static Double divisione(int a, int b){
        return (double) a/b;
    }
}
